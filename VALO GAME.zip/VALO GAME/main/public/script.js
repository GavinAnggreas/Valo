document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting the default way

    // Collect form data
    const blogTitle = document.querySelector('input[name="blogTitle"]').value;
    const blogSnippet = document.querySelector('input[name="blogSnippet"]').value;
    const blogBody = document.querySelector('textarea[name="blogBody"]').value;

    // Send the data to the backend
    fetch('/addBlog', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            title: blogTitle,
            snippet: blogSnippet,
            body: blogBody
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Blog successfully added!');
            // Optionally, you can redirect to the blog page
            window.location.href = '/blog'; // Redirect to "BLOGS" section
        } else {
            alert('Error adding blog.');
        }
    })
    .catch(error => console.error('Error:', error));
});
